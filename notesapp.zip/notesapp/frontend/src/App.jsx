import CreateNote from "./pages/CreateNote";

function App() {
  return <CreateNote />;
}

export default App;
